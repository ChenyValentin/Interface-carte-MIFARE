var dir_3f45b78a281ff7342088d1a157e24ab8 =
[
    [ "Device", "dir_2434136eed3140507807179c9e59eca8.html", "dir_2434136eed3140507807179c9e59eca8" ],
    [ "ISO14443A-3", "dir_5f71bd4f647187718ab448e1b4413f17.html", "dir_5f71bd4f647187718ab448e1b4413f17" ],
    [ "Mf_Classic", "dir_12c870651b2a4d1981c209dec21d4b5a.html", "dir_12c870651b2a4d1981c209dec21d4b5a" ]
];