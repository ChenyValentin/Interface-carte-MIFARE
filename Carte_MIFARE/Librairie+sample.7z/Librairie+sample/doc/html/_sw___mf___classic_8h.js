var _sw___mf___classic_8h =
[
    [ "ACC_AUTH_NORMAL", "_sw___mf___classic_8h.html#ae68729036643ac6e4879abe69986d86c", null ],
    [ "ACC_AUTH_TRANSPORT", "_sw___mf___classic_8h.html#a4a1d90b578d325a8881762fd474a8226", null ],
    [ "ACC_BLOCK_READWRITE", "_sw___mf___classic_8h.html#a0353b2ab14b23c7b61d8a1b3f971d6e2", null ],
    [ "ACC_BLOCK_TRANSPORT", "_sw___mf___classic_8h.html#a400094b3a5aff40e7c0b87f980570b78", null ],
    [ "ACC_BLOCK_VALUE", "_sw___mf___classic_8h.html#aa9b29150f42225ec0a8bdfe39ec3431e", null ],
    [ "AuthKeyA", "_sw___mf___classic_8h.html#ae83637bed87e695525d01a2977c0eebd", null ],
    [ "AuthKeyB", "_sw___mf___classic_8h.html#a2a61f7b119ec26b10fe8fdf49814b320", null ],
    [ "Mf_Classic_Authenticate", "_sw___mf___classic_8h.html#a3c41c6cd907e21efe6f996e83810c9d2", null ],
    [ "Mf_Classic_Decrement_Value", "_sw___mf___classic_8h.html#a91d10b6715e1b9e590be18bf2386c8fe", null ],
    [ "Mf_Classic_Increment_Value", "_sw___mf___classic_8h.html#ad9407399e5d7b50f8ad12c5ca800a6d0", null ],
    [ "Mf_Classic_LoadKey", "_sw___mf___classic_8h.html#a73f7ad46298b7c424c0e6f4c7a261068", null ],
    [ "Mf_Classic_LoadKey2", "_sw___mf___classic_8h.html#ac55917178d444d1f7f6e0172d0df4803", null ],
    [ "Mf_Classic_PersonalizeUID", "_sw___mf___classic_8h.html#adbe71133a29caf62bdce3f03e189cd0e", null ],
    [ "Mf_Classic_Read_Block", "_sw___mf___classic_8h.html#ae2c486b939d2cd97ef53f121279a4364", null ],
    [ "Mf_Classic_Read_Sector", "_sw___mf___classic_8h.html#a2ac525120085e8dfd9f5ae41ff79b2ec", null ],
    [ "Mf_Classic_Read_Value", "_sw___mf___classic_8h.html#a5dc2eed175b2898aab3c2a23f9f91a69", null ],
    [ "Mf_Classic_Restore_Value", "_sw___mf___classic_8h.html#af6bdf82067a1a7288cd43bf24b5e072b", null ],
    [ "Mf_Classic_UpdadeAccessBlock", "_sw___mf___classic_8h.html#ab2e7f476afca5b677d4e330df2bc0c76", null ],
    [ "Mf_Classic_Write_Block", "_sw___mf___classic_8h.html#a370d9020a75874ebacbda9635c72209a", null ],
    [ "Mf_Classic_Write_Sector", "_sw___mf___classic_8h.html#ad4d87f6c953f23f583f7c40c69bd2b32", null ],
    [ "Mf_Classic_Write_Value", "_sw___mf___classic_8h.html#a0d9b6753cad40b1d641a948971914f10", null ]
];