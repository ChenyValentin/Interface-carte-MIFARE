var searchData=
[
  ['hardware_2eh_0',['Hardware.h',['../_hardware_8h.html',1,'']]],
  ['hsocket_1',['hSocket',['../struct_reader_name.html#acd3f33bcffa3415a0b8a58706fcc0dcd',1,'ReaderName']]]
];
