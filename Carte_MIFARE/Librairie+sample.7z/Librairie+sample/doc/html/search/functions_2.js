var searchData=
[
  ['gestiondeconnection_0',['GestionDeconnection',['../_sw___device_8h.html#a339a933bfd0f156312498681d5b3a1e4',1,'Sw_Device.h']]],
  ['get_5fproperty_1',['Get_Property',['../_sw___device_8h.html#a435839693906c0be92b4823bb25c52ad',1,'Sw_Device.h']]],
  ['geterrormessage_2',['GetErrorMessage',['../_sw___device_8h.html#a3df82c2bc60a0273b017cbd21dbf63a7',1,'Sw_Device.h']]],
  ['getlibraryextension_3',['GetLibraryExtension',['../_sw___device_8h.html#a81f9bee2dd29fef240b389f33d9bcc84',1,'Sw_Device.h']]]
];
