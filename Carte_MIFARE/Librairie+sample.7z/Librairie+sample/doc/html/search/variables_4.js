var searchData=
[
  ['serial_0',['serial',['../struct_reader_name.html#a7713b82f71b199d461dca3796410d1cf',1,'ReaderName']]],
  ['stack_1',['stack',['../struct_reader_name.html#a1e0e5541fa2a95dc1a1865c9c27790d2',1,'ReaderName']]]
];
