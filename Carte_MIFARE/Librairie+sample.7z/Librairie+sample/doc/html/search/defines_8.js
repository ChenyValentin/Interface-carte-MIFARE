var searchData=
[
  ['rdmux_5fchanges_5ftreated_0',['RdMUX_CHANGES_TREATED',['../_mf_err_no_8h.html#ae739c3dd3b544b580aee35ad6eee2cb6',1,'MfErrNo.h']]],
  ['rdmux_5ferr_5fbase_5fend_1',['RdMUX_ERR_BASE_END',['../_mf_err_no_8h.html#adbdbb00972845cdc5978b6de1d735d15',1,'MfErrNo.h']]],
  ['rdmux_5ferr_5fbase_5fstart_2',['RdMUX_ERR_BASE_START',['../_mf_err_no_8h.html#ade6070ef131369a51cd85625ac26c8e4',1,'MfErrNo.h']]],
  ['rdmux_5fmuxmode_5fnot_5fsupported_5frm_3',['RdMUX_MUXMODE_NOT_SUPPORTED_RM',['../_mf_err_no_8h.html#a8b6de2b4bbeeec181d61d95f6139215d',1,'MfErrNo.h']]],
  ['rdmux_5fno_5frd_5favail_4',['RdMUX_NO_RD_AVAIL',['../_mf_err_no_8h.html#a98cc58b1a1a17bd3c27ef47080b39675',1,'MfErrNo.h']]],
  ['rdmux_5fok_5',['RdMUX_OK',['../_mf_err_no_8h.html#a1ecf95098cb11a06b7a5fa0d5a446e4e',1,'MfErrNo.h']]],
  ['rdmux_5frdindex_5fout_5fof_5frange_6',['RdMUX_RdINDEX_OUT_OF_RANGE',['../_mf_err_no_8h.html#a39bf7dfe208ce02a1d7325b22a39c52a',1,'MfErrNo.h']]],
  ['rdmux_5fselected_5frd_5fnavail_7',['RdMUX_SELECTED_RD_NAVAIL',['../_mf_err_no_8h.html#a5a99a91b9655c2b5412fec4a58698aef',1,'MfErrNo.h']]],
  ['rdmux_5fselectionlist_5fempty_8',['RdMUX_SELECTIONLIST_EMPTY',['../_mf_err_no_8h.html#aa698488063e87ba84e1450ef353d2d64',1,'MfErrNo.h']]],
  ['rdmux_5funknown_5fparamidx_9',['RdMUX_UNKNOWN_PARAMIDX',['../_mf_err_no_8h.html#a03ca499c46f4004af29676034d230104',1,'MfErrNo.h']]],
  ['reader_5ferr_5fbase_5fend_10',['READER_ERR_BASE_END',['../_mf_err_no_8h.html#a393585c434077a797aaabd41d4e5d4ff',1,'MfErrNo.h']]],
  ['reader_5ferr_5fbase_5fstart_11',['READER_ERR_BASE_START',['../_mf_err_no_8h.html#ab9c8080abfd5e7b2910ea51fa370235e',1,'MfErrNo.h']]],
  ['readercdc_12',['ReaderCDC',['../_hardware_8h.html#a402be734ca15b678264030407614819e',1,'Hardware.h']]],
  ['readerpcsc_13',['ReaderPCSC',['../_hardware_8h.html#a4b015126f6998d9a977baafcf42dc627',1,'Hardware.h']]],
  ['readertcp_14',['ReaderTCP',['../_hardware_8h.html#a48be0d33847d6266741d9a8f34db3415',1,'Hardware.h']]]
];
