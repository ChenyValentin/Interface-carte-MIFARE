var searchData=
[
  ['iso14443_5f3_5fa_5fhalt_0',['ISO14443_3_A_Halt',['../_sw___i_s_o14443_a-3_8h.html#a331f89d183eeb53c6292af893da76a84',1,'Sw_ISO14443A-3.h']]],
  ['iso14443_5f3_5fa_5fpollcard_1',['ISO14443_3_A_PollCard',['../_sw___i_s_o14443_a-3_8h.html#a7483320ae89f50da5f5b3c80cc9b5c2a',1,'Sw_ISO14443A-3.h']]],
  ['iso14443_5f3_5fa_5fpollcardwu_2',['ISO14443_3_A_PollCardWU',['../_sw___i_s_o14443_a-3_8h.html#ac294caa1ebcc1607edb018f8e6da97b1',1,'Sw_ISO14443A-3.h']]]
];
