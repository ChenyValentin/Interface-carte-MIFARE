var searchData=
[
  ['bool_0',['BOOL',['../_type_defs_8h.html#ad2f8ed01c1733d4eab0932d970abaa4c',1,'TypeDefs.h']]]
];
