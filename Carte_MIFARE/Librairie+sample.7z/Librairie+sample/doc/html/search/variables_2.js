var searchData=
[
  ['hsocket_0',['hSocket',['../struct_reader_name.html#acd3f33bcffa3415a0b8a58706fcc0dcd',1,'ReaderName']]]
];
