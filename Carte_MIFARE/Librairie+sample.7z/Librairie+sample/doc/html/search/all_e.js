var searchData=
[
  ['version_0',['version',['../struct_reader_name.html#ad3989e824983c719481ceed5a991fdd3',1,'ReaderName']]],
  ['version_1',['Version',['../_sw___device_8h.html#a043b63e09d0926eda10617a222ba8f50',1,'Sw_Device.h']]]
];
