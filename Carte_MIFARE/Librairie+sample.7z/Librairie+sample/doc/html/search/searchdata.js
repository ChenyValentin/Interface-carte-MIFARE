var indexSectionsWithContent =
{
  0: "abcdghilmorstuv",
  1: "r",
  2: "hmst",
  3: "bcgilmorsv",
  4: "dghistv",
  5: "biu",
  6: "abcdgilmrt",
  7: "t",
  8: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Macros",
  7: "Groupes",
  8: "Pages"
};

