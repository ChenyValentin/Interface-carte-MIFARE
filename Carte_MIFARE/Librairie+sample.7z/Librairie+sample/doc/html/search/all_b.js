var searchData=
[
  ['serial_0',['serial',['../struct_reader_name.html#a7713b82f71b199d461dca3796410d1cf',1,'ReaderName']]],
  ['set_5fproperty_1',['Set_Property',['../_sw___device_8h.html#a6a8d165def56be2b443806d71f337e33',1,'Sw_Device.h']]],
  ['stack_2',['stack',['../struct_reader_name.html#a1e0e5541fa2a95dc1a1865c9c27790d2',1,'ReaderName']]],
  ['sw_5fdevice_2eh_3',['Sw_Device.h',['../_sw___device_8h.html',1,'']]],
  ['sw_5fiso14443a_2d3_2eh_4',['Sw_ISO14443A-3.h',['../_sw___i_s_o14443_a-3_8h.html',1,'']]],
  ['sw_5fmf_5fclassic_2eh_5',['Sw_Mf_Classic.h',['../_sw___mf___classic_8h.html',1,'']]]
];
