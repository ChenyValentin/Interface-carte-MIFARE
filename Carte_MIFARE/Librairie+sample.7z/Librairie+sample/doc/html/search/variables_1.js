var searchData=
[
  ['g_5fhcom_0',['g_hCOM',['../struct_reader_name.html#a495277a04359ac7c34090c93b7ebb928',1,'ReaderName']]]
];
