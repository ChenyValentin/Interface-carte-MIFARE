var searchData=
[
  ['ipreader_0',['IPReader',['../struct_reader_name.html#a24362ae702baa403025803d02aceb47a',1,'ReaderName']]]
];
