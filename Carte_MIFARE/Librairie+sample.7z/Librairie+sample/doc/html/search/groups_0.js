var searchData=
[
  ['type_0',['Type',['../group___type.html',1,'']]]
];
