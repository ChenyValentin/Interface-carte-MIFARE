var searchData=
[
  ['type_0',['Type',['../struct_reader_name.html#aeff746a68ed515a1d9f0c40a38dd200b',1,'ReaderName']]]
];
