var searchData=
[
  ['device_0',['device',['../struct_reader_name.html#a2376f17d1e7367401184b2a3978bcd3a',1,'ReaderName']]]
];
