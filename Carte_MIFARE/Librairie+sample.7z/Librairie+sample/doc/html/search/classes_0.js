var searchData=
[
  ['readername_0',['ReaderName',['../struct_reader_name.html',1,'']]]
];
