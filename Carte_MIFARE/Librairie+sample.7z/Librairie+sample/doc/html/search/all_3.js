var searchData=
[
  ['datamem_0',['DataMem',['../_hardware_8h.html#a76644fd4893da5414a36a97a9c45733b',1,'Hardware.h']]],
  ['delays_5fms_1',['DELAYS_MS',['../_tools_8h.html#ad6fec1d7c581133d41f31ba8722500ac',1,'Tools.h']]],
  ['delays_5fs_2',['DELAYS_S',['../_tools_8h.html#a507009414b4ea0a70bb8cbac73336ac7',1,'Tools.h']]],
  ['device_3',['device',['../struct_reader_name.html#a2376f17d1e7367401184b2a3978bcd3a',1,'ReaderName']]]
];
