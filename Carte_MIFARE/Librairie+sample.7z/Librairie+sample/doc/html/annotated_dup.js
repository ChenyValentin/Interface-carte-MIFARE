var annotated_dup =
[
    [ "ReaderName", "struct_reader_name.html", "struct_reader_name" ]
];