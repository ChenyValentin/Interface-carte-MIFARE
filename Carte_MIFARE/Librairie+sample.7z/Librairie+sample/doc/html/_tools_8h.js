var _tools_8h =
[
    [ "DELAYS_MS", "_tools_8h.html#ad6fec1d7c581133d41f31ba8722500ac", null ],
    [ "DELAYS_S", "_tools_8h.html#a507009414b4ea0a70bb8cbac73336ac7", null ]
];