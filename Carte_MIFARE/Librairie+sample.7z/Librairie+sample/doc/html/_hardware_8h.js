var _hardware_8h =
[
    [ "ReaderName", "struct_reader_name.html", "struct_reader_name" ],
    [ "BlockingEnabled", "_hardware_8h.html#a83b51cbace5260e754a55e1542bb9eba", null ],
    [ "DataMem", "_hardware_8h.html#a76644fd4893da5414a36a97a9c45733b", null ],
    [ "MAX_WAIT_READ", "_hardware_8h.html#a1d05c30f7505516a5730276a40d39a06", null ],
    [ "MAX_WAIT_READ_TO_BIT", "_hardware_8h.html#af2723c03d46829890de721bf78bc173e", null ],
    [ "ReaderCDC", "_hardware_8h.html#a402be734ca15b678264030407614819e", null ],
    [ "ReaderPCSC", "_hardware_8h.html#a4b015126f6998d9a977baafcf42dc627", null ],
    [ "ReaderTCP", "_hardware_8h.html#a48be0d33847d6266741d9a8f34db3415", null ]
];