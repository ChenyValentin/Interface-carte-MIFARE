var struct_l_i_b___v_e_r_s_i_o_n =
[
    [ "VMajor", "struct_l_i_b___v_e_r_s_i_o_n.html#a759996661a0b8e5ec8aa14844afb5b49", null ],
    [ "VMinor", "struct_l_i_b___v_e_r_s_i_o_n.html#ad6a22aca7bdb60ece2a8fa9d7412eab1", null ],
    [ "VPatch", "struct_l_i_b___v_e_r_s_i_o_n.html#ae338c6159ec26cf358294d1c311361ef", null ]
];