var group___type =
[
    [ "int16_t", "group___type.html#gaa343fa3b3d06292b959ffdd4c4703b06", null ],
    [ "int32_t", "group___type.html#ga7cf4a942912b990a96c39f9a2b81aa32", null ],
    [ "int64_t", "group___type.html#ga20c5e9a94aaa5a66a9f0165f027a8581", null ],
    [ "int8_t", "group___type.html#gaef44329758059c91c76d334e8fc09700", null ],
    [ "uint16_t", "group___type.html#ga273cf69d639a59973b6019625df33e30", null ],
    [ "uint32_t", "group___type.html#ga33594304e786b158f3fb30289278f5af", null ],
    [ "uint64_t", "group___type.html#gad27ed092432b64ff558d2254c278720f", null ],
    [ "uint8_t", "group___type.html#gaba7bc1797add20fe3efdf37ced1182c5", null ]
];