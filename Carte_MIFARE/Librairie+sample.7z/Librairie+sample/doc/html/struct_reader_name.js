var struct_reader_name =
[
    [ "device", "struct_reader_name.html#a2376f17d1e7367401184b2a3978bcd3a", null ],
    [ "g_hCOM", "struct_reader_name.html#a495277a04359ac7c34090c93b7ebb928", null ],
    [ "hSocket", "struct_reader_name.html#acd3f33bcffa3415a0b8a58706fcc0dcd", null ],
    [ "IPReader", "struct_reader_name.html#a24362ae702baa403025803d02aceb47a", null ],
    [ "serial", "struct_reader_name.html#a7713b82f71b199d461dca3796410d1cf", null ],
    [ "stack", "struct_reader_name.html#a1e0e5541fa2a95dc1a1865c9c27790d2", null ],
    [ "Type", "struct_reader_name.html#aeff746a68ed515a1d9f0c40a38dd200b", null ],
    [ "version", "struct_reader_name.html#ad3989e824983c719481ceed5a991fdd3", null ]
];